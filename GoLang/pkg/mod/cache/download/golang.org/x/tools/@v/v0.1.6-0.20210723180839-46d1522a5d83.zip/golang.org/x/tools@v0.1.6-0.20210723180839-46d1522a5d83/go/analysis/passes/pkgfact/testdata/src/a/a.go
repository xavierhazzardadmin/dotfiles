package a

const _greeting_ = "hello"
const _audience_ = "world"
