// Package pkg ...
package pkg

func Fn13() t1        { return 0 }
func Fn14() *t1       { return nil }
func (Recv) Fn15() t1 { return 0 }
