package pkg

func fn() {} // unused used_test
