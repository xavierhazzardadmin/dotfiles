package pkg

import "testing"

func TestMain(m *testing.M) {
	m.Run()
}
