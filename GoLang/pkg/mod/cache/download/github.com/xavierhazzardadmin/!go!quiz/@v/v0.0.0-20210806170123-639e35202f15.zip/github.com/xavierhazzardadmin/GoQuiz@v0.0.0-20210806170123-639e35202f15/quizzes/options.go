package quizzes

var CodingQuestions = []string{"What is the easiest programming language to use for full stack development?", "How many bits are in a single byte?", "Which company first backed the GoLang project?", "What is the styling language you use in the web called?", "What year does time start?"}

var CodingAnswers = []string{"javascript", "8", "google", "css", "1970"}

var ActorQuestions = []string{"Who is the highest paid actor in the world?", "How many Olsen sisters are there?", "Which marvel actor has been in the most movies?", "Who played Ben Kenobi in A new Hope?", "Who is the youngest female actor to have a hit single in the charts?"}

var ActorAnswers = []string{"Dwayne Johnson", "3", "Robert Downey Junior", "Alec Guinness", "Olivia Rodrigo"}

var GKQuestions = []string{"Is a Tomato a vegatable or a fruit?", "How old was Jesus when he died on earth?", "Who is the richest person on the world to this day?", "How old is Thor in the marvel universe (in years)?", "What is the name of the thing that hangs between your tonsils?"}

var GKAnswers = []string{"Fruit", "33", "Bernard Arnault", "1500", "Uvula"}

var GamingQuestions = []string{"What year was Rocket League released?", "What is the most played game in the world?", "What month did Fortnite come out in?", "What year did minecraft come out in?", "What is the best car in Rocket League?"}

var GamingAnswers = []string{"2015", "PUBG", "September", "2011", "Octane"}

var TechQuestions = []string{"Who is the creator of Linux?", "What is the latest release of the windows operating system?", "In what year did Windows 10 come out?", "How many PlayStation consoles are there?", "Where is the best place to get a job in tech?"}

var TechAnswers = []string{"Linus Torvalds", "10", "2015", "7", "Silicon Valley"}
